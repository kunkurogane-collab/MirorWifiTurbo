package com.example.mirrorwifiturbo

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.text.format.Formatter
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.DataInputStream
import java.net.Socket

class MainActivity : AppCompatActivity() {

    private lateinit var controlPanel: LinearLayout
    private lateinit var viewerContainer: FrameLayout
    private lateinit var surfaceView: SurfaceView
    private lateinit var tvMyIp: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btnStartShare: Button
    private lateinit var btnStopShare: Button
    private lateinit var etTargetIp: EditText

    @Volatile private var isViewing = false
    private var viewSocket: Socket? = null

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, ScreenMirrorService::class.java).apply {
                putExtra("RESULT_CODE", result.resultCode)
                putExtra("DATA", result.data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            btnStartShare.visibility = View.GONE
            btnStopShare.visibility = View.VISIBLE
            tvStatus.text = "Status: Menunggu HP Kedua terhubung ke IP di atas..."
        } else {
            tvStatus.text = "Status: Izin rekam layar ditolak."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        controlPanel = findViewById(R.id.controlPanel)
        viewerContainer = findViewById(R.id.viewerContainer)
        surfaceView = findViewById(R.id.surfaceView)
        tvMyIp = findViewById(R.id.tvMyIp)
        tvStatus = findViewById(R.id.tvStatus)
        btnStartShare = findViewById(R.id.btnStartShare)
        btnStopShare = findViewById(R.id.btnStopShare)
        etTargetIp = findViewById(R.id.etTargetIp)

        tvMyIp.text = "IP WiFi HP Ini: ${getLocalWifiIp()}"

        btnStartShare.setOnClickListener {
            val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
        }

        btnStopShare.setOnClickListener {
            val stopIntent = Intent(this, ScreenMirrorService::class.java).apply { action = "STOP" }
            startService(stopIntent)
            btnStopShare.visibility = View.GONE
            btnStartShare.visibility = View.VISIBLE
            tvStatus.text = "Status: Berbagi layar dihentikan."
        }

        findViewById<Button>(R.id.btnConnectView).setOnClickListener {
            val targetIp = etTargetIp.text.toString().trim()
            if (targetIp.isEmpty()) {
                Toast.makeText(this, "Masukkan IP HP Utama terlebih dahulu", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startViewing(targetIp)
        }

        findViewById<Button>(R.id.btnDisconnectView).setOnClickListener {
            stopViewing()
        }
    }

    private fun startViewing(ip: String) {
        controlPanel.visibility = View.GONE
        viewerContainer.visibility = View.VISIBLE
        isViewing = true

        surfaceView.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                Thread { connectAndDecode(ip, holder) }.start()
            }
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
            override fun surfaceDestroyed(holder: SurfaceHolder) {
                stopViewing()
            }
        })
    }

    private fun connectAndDecode(ip: String, holder: SurfaceHolder) {
        var decoder: MediaCodec? = null
        try {
            val socket = Socket(ip, ScreenMirrorService.PORT)
            socket.tcpNoDelay = true
            viewSocket = socket
            val inputStream = DataInputStream(socket.getInputStream())

            val format = MediaFormat.createVideoFormat(
                MediaFormat.MIMETYPE_VIDEO_AVC,
                ScreenMirrorService.VIDEO_WIDTH,
                ScreenMirrorService.VIDEO_HEIGHT
            )
            decoder = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC).apply {
                configure(format, holder.surface, null, 0)
                start()
            }

            val bufferInfo = MediaCodec.BufferInfo()
            while (isViewing) {
                val frameSize = inputStream.readInt()
                if (frameSize <= 0 || frameSize > 5_000_000) break

                val frameData = ByteArray(frameSize)
                inputStream.readFully(frameData)

                val inputIndex = decoder.dequeueInputBuffer(10_000)
                if (inputIndex >= 0) {
                    val inputBuffer = decoder.getInputBuffer(inputIndex)
                    inputBuffer?.clear()
                    inputBuffer?.put(frameData)
                    decoder.queueInputBuffer(inputIndex, 0, frameSize, System.nanoTime() / 1000, 0)
                }

                var outputIndex = decoder.dequeueOutputBuffer(bufferInfo, 10_000)
                while (outputIndex >= 0) {
                    decoder.releaseOutputBuffer(outputIndex, true)
                    outputIndex = decoder.dequeueOutputBuffer(bufferInfo, 0)
                }
            }
        } catch (e: Exception) {
            runOnUiThread {
                Toast.makeText(this, "Koneksi terputus: ${e.message}", Toast.LENGTH_SHORT).show()
                stopViewing()
            }
        } finally {
            try {
                decoder?.stop()
                decoder?.release()
            } catch (_: Exception) {}
        }
    }

    private fun stopViewing() {
        isViewing = false
        try { viewSocket?.close() } catch (_: Exception) {}
        runOnUiThread {
            viewerContainer.visibility = View.GONE
            controlPanel.visibility = View.VISIBLE
        }
    }

    @Suppress("DEPRECATION")
    private fun getLocalWifiIp(): String {
        val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ipInt = wifiManager.connectionInfo.ipAddress
        return if (ipInt == 0) "Tidak terhubung WiFi" else Formatter.formatIpAddress(ipInt)
    }
}
