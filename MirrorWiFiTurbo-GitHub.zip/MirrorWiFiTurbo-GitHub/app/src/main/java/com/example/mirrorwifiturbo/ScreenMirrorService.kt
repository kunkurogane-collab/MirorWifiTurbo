package com.example.mirrorwifiturbo

import android.app.*
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.DataOutputStream
import java.net.ServerSocket
import java.net.Socket

class ScreenMirrorService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var mediaCodec: MediaCodec? = null
    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null
    @Volatile private var isRunning = false

    companion object {
        const val PORT = 8888
        // Resolusi rendah & bitrate kecil agar super ngebut di WiFi (burik tidak masalah)
        const val VIDEO_WIDTH = 360
        const val VIDEO_HEIGHT = 640
        const val VIDEO_BITRATE = 400_000 // 400 Kbps
        const val VIDEO_FPS = 20
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopEverything()
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundNotification()

        val resultCode = intent?.getIntExtra("RESULT_CODE", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra("DATA", Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra("DATA")
        } ?: return START_NOT_STICKY

        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)

        isRunning = true
        Thread { startServerAndStream() }.start()

        return START_NOT_STICKY
    }

    private fun startForegroundNotification() {
        val channelId = "mirror_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Screen Mirroring", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("MirrorWiFi Turbo Aktif")
            .setContentText("Sedang membagikan layar ke HP kedua via WiFi...")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .build()

        startForeground(101, notification)
    }

    private fun startServerAndStream() {
        try {
            serverSocket = ServerSocket(PORT)
            while (isRunning) {
                val socket = serverSocket?.accept() ?: break
                socket.tcpNoDelay = true
                clientSocket = socket

                streamScreenToClient(DataOutputStream(socket.getOutputStream()))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun streamScreenToClient(outputStream: DataOutputStream) {
        try {
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, VIDEO_WIDTH, VIDEO_HEIGHT).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, VIDEO_BITRATE)
                setInteger(MediaFormat.KEY_FRAME_RATE, VIDEO_FPS)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            mediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC).apply {
                configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            }

            val inputSurface = mediaCodec!!.createInputSurface()
            mediaCodec!!.start()

            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "MirrorDisplay",
                VIDEO_WIDTH,
                VIDEO_HEIGHT,
                160,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                inputSurface,
                null,
                null
            )

            val bufferInfo = MediaCodec.BufferInfo()
            while (isRunning && clientSocket?.isConnected == true) {
                val outputBufferId = mediaCodec!!.dequeueOutputBuffer(bufferInfo, 10_000)
                if (outputBufferId >= 0) {
                    val encodedData = mediaCodec!!.getOutputBuffer(outputBufferId)
                    if (encodedData != null && bufferInfo.size > 0) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)

                        val bytes = ByteArray(bufferInfo.size)
                        encodedData.get(bytes)

                        outputStream.writeInt(bytes.size)
                        outputStream.write(bytes)
                        outputStream.flush()
                    }
                    mediaCodec!!.releaseOutputBuffer(outputBufferId, false)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            releaseEncoder()
        }
    }

    private fun releaseEncoder() {
        try {
            virtualDisplay?.release()
            mediaCodec?.stop()
            mediaCodec?.release()
            clientSocket?.close()
        } catch (_: Exception) {}
        virtualDisplay = null
        mediaCodec = null
        clientSocket = null
    }

    private fun stopEverything() {
        isRunning = false
        releaseEncoder()
        try {
            serverSocket?.close()
            mediaProjection?.stop()
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        stopEverything()
        super.onDestroy()
    }
}
