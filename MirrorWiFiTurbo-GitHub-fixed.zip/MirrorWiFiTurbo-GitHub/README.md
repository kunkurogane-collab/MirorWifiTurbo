# MirrorWiFi Turbo (versi diperbaiki)

Mirror layar HP lewat WiFi: **HP Utama** membagikan layar, **HP Kedua** menampilkannya.
H.264 hardware (MediaProjection + MediaCodec) lewat TCP, port 8888.

## Cara pakai
1. Kedua HP di WiFi yang sama (atau HP Utama menyalakan hotspot, HP Kedua tersambung ke hotspot itu).
2. HP Utama: pilih kualitas -> **Mulai Bagikan Layar** -> izinkan. Catat **IP** dan **PIN 6 angka**.
3. HP Kedua: isi IP + PIN -> **Hubungkan**. Tombol Back / "Tutup" untuk berhenti.

## Build
- GitHub: push ke `main` -> tab Actions -> unduh artifact `MirrorWiFi-Turbo-APK`.
- Lokal: buka di Android Studio, Run.

## Perbaikan dibanding versi unggahan
| # | Masalah | Dampak | Perbaikan |
|---|---------|--------|-----------|
| 1 | Manifest: `category.CATEGORY_LAUNCHER` | Ikon app tidak muncul di launcher | `category.LAUNCHER` |
| 2 | Tidak ada `MediaProjection.registerCallback` | **Crash di Android 14+** saat `createVirtualDisplay` | Callback didaftarkan; layar dihentikan dari chip sistem ikut menghentikan service |
| 3 | Encoder + VirtualDisplay dibuat ulang tiap klien baru | Sambung ulang **crash** di Android 14+ (token projection hanya sekali pakai) | Encoder/VirtualDisplay dibuat sekali, dibagi ke semua klien |
| 4 | Satu klien saja, menulis socket langsung dari thread encoder | Jaringan lambat menahan encoder, latensi menumpuk | Antrean + thread per klien; antrean penuh -> buang & minta keyframe |
| 5 | Resolusi tetap 360x640 | Layar 20:9 jadi gepeng/buram | Ukuran mengikuti rasio layar asli, kualitas bisa dipilih |
| 6 | Penerima merentangkan video ke `match_parent` | Gambar tertarik | Surface dipasang sesuai rasio video |
| 7 | `addCallback` surface ditambah tiap klik "Hubungkan" | Beberapa thread menyambung sekaligus | Callback sekali di `onCreate`, sesi dibatalkan via `viewGeneration` |
| 8 | `Socket(ip, port)` tanpa timeout | Menggantung ±2 menit jika IP salah | Timeout 5 dtk (connect), 10 dtk (baca) |
| 9 | SPS/PPS tidak ditandai CODEC_CONFIG; paket tanpa tipe | Decoder rawan gagal / hitam | Paket bertipe (HELLO/CONFIG/KEY/DELTA/PING); config dikirim sebagai CODEC_CONFIG |
| 10 | Layar diam = tidak ada frame | Penerima hitam/beku, putus tak terdeteksi | `repeat-previous-frame-after` + PING tiap 1 dtk |
| 11 | Frame menumpuk di decoder | Latensi naik | Hanya frame terbaru yang dirender |
| 12 | `WifiManager.connectionInfo` (deprecated) | IP "0" saat hotspot / tidak terupdate | Enumerasi antarmuka jaringan, diperbarui tiap detik |
| 13 | Tanpa autentikasi | Siapa pun di WiFi yang sama bisa melihat layar | PIN 6 angka acak per sesi |
| 14 | Tanpa WifiLock | Latensi WiFi naik-turun (power save) | `WIFI_MODE_FULL_LOW_LATENCY` |
| 15 | `startForeground` tanpa tipe, tanpa izin notifikasi | Notifikasi tak tampil di Android 13+ | Tipe `mediaProjection` eksplisit + minta `POST_NOTIFICATIONS`, tombol Berhenti di notifikasi |
| 16 | CI `gradle wrapper` manual, tanpa cache | Lambat | `gradle/actions/setup-gradle@v4` (Gradle 8.7, cache) |

## Batasan
- Belum ada audio.
- Orientasi video ditetapkan saat mulai (mulai dari mode potret); rotasi ke landscape akan di-letterbox.
- Belum dikompilasi/diuji di perangkat. Kemungkinan ada penyesuaian kecil saat build pertama.
- Lalu lintas TCP tidak dienkripsi; PIN hanya mencegah penonton iseng, bukan penyadapan aktif. Pakai WiFi yang tepercaya.
