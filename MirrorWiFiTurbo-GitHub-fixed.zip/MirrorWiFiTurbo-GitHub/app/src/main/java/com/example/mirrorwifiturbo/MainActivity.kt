package com.example.mirrorwifiturbo

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.security.SecureRandom
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private data class Preset(val label: String, val longSide: Int, val bitrate: Int)

    private val presets = listOf(
        Preset("Turbo - 360p, 0.8 Mbps (paling ringan)", 640, 800_000),
        Preset("Seimbang - 720p, 3 Mbps", 1280, 3_000_000),
        Preset("Tajam - 1080p, 8 Mbps", 1920, 8_000_000)
    )

    private lateinit var controlPanel: LinearLayout
    private lateinit var viewerContainer: FrameLayout
    private lateinit var surfaceView: SurfaceView
    private lateinit var tvMyIp: TextView
    private lateinit var tvPin: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btnStartShare: Button
    private lateinit var btnStopShare: Button
    private lateinit var etTargetIp: EditText
    private lateinit var etPin: EditText
    private lateinit var spQuality: Spinner

    private val ui = Handler(Looper.getMainLooper())
    private var shareStartedAt = 0L

    // --- State penerima ---
    @Volatile private var viewGeneration = 0      // naik setiap sesi dibatalkan -> thread lama berhenti
    @Volatile private var viewSocket: Socket? = null
    private var viewerThread: Thread? = null
    private var pendingIp: String? = null
    private var pendingPin: String = ""
    private var videoW = 0
    private var videoH = 0
    private var wifiLock: WifiManager.WifiLock? = null

    private val ticker = object : Runnable {
        override fun run() {
            refreshShareUi()
            ui.postDelayed(this, 1000)
        }
    }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            val pin = "%06d".format(SecureRandom().nextInt(1_000_000))
            val preset = presets[spQuality.selectedItemPosition.coerceIn(0, presets.lastIndex)]
            val serviceIntent = Intent(this, ScreenMirrorService::class.java).apply {
                putExtra(ScreenMirrorService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenMirrorService.EXTRA_DATA, data)
                putExtra(ScreenMirrorService.EXTRA_PIN, pin)
                putExtra(ScreenMirrorService.EXTRA_LONG_SIDE, preset.longSide)
                putExtra(ScreenMirrorService.EXTRA_BITRATE, preset.bitrate)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            shareStartedAt = SystemClock.elapsedRealtime()
            tvPin.text = "PIN: $pin"
            tvPin.visibility = View.VISIBLE
            btnStartShare.visibility = View.GONE
            btnStopShare.visibility = View.VISIBLE
            tvStatus.text = "Status: Menunggu HP Kedua. Masukkan IP + PIN di atas."
        } else {
            tvStatus.text = "Status: Izin rekam layar ditolak."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        controlPanel = findViewById(R.id.controlPanel)
        viewerContainer = findViewById(R.id.viewerContainer)
        surfaceView = findViewById(R.id.surfaceView)
        tvMyIp = findViewById(R.id.tvMyIp)
        tvPin = findViewById(R.id.tvPin)
        tvStatus = findViewById(R.id.tvStatus)
        btnStartShare = findViewById(R.id.btnStartShare)
        btnStopShare = findViewById(R.id.btnStopShare)
        etTargetIp = findViewById(R.id.etTargetIp)
        etPin = findViewById(R.id.etPin)
        spQuality = findViewById(R.id.spQuality)

        spQuality.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, presets.map { it.label }
        )
        spQuality.setSelection(1)

        etTargetIp.setText(getPreferences(Context.MODE_PRIVATE).getString("last_ip", ""))

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        // Callback surface didaftarkan SEKALI (sebelumnya ditambah tiap tombol ditekan -> koneksi ganda)
        surfaceView.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                if (pendingIp != null) launchViewer()
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                stopViewerThread()
            }
        })

        btnStartShare.setOnClickListener {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            screenCaptureLauncher.launch(mpm.createScreenCaptureIntent())
        }

        btnStopShare.setOnClickListener {
            startService(Intent(this, ScreenMirrorService::class.java).setAction(ScreenMirrorService.ACTION_STOP))
            shareStartedAt = 0L
            btnStopShare.visibility = View.GONE
            btnStartShare.visibility = View.VISIBLE
            tvPin.visibility = View.GONE
            tvStatus.text = "Status: Berbagi layar dihentikan."
        }

        findViewById<Button>(R.id.btnConnectView).setOnClickListener {
            val ip = etTargetIp.text.toString().trim()
            val pin = etPin.text.toString().trim()
            if (ip.isEmpty()) {
                Toast.makeText(this, "Masukkan IP HP Utama terlebih dahulu", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (pin.length != 6) {
                Toast.makeText(this, "Masukkan PIN 6 angka yang tampil di HP Utama", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            getPreferences(Context.MODE_PRIVATE).edit().putString("last_ip", ip).apply()
            startViewing(ip, pin)
        }

        findViewById<Button>(R.id.btnDisconnectView).setOnClickListener { stopViewing() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (viewerContainer.visibility == View.VISIBLE) {
                    stopViewing()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        stopViewerThread()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ PENGIRIM (UI)

    private fun refreshShareUi() {
        val ips = NetUtil.localIps()
        tvMyIp.text = "IP HP Ini: " + (if (ips.isEmpty()) "Tidak terhubung WiFi" else ips.joinToString(" / "))

        val active = ScreenMirrorService.running ||
            (shareStartedAt != 0L && SystemClock.elapsedRealtime() - shareStartedAt < 4000)
        btnStartShare.visibility = if (active) View.GONE else View.VISIBLE
        btnStopShare.visibility = if (active) View.VISIBLE else View.GONE
        if (active) {
            if (ScreenMirrorService.currentPin.isNotEmpty()) {
                tvPin.text = "PIN: ${ScreenMirrorService.currentPin}"
                tvPin.visibility = View.VISIBLE
            }
            if (ScreenMirrorService.running) {
                val n = ScreenMirrorService.clientCount
                tvStatus.text = if (n == 0) "Status: Berbagi aktif - menunggu penerima"
                else "Status: Berbagi aktif - $n penerima tersambung"
            }
        } else if (shareStartedAt != 0L) {
            // service berhenti sendiri (mis. dihentikan dari chip sistem / port bentrok)
            shareStartedAt = 0L
            tvPin.visibility = View.GONE
            tvStatus.text = "Status: Berbagi berhenti."
        }
    }

    // ------------------------------------------------------------------ PENERIMA

    private fun startViewing(ip: String, pin: String) {
        pendingIp = ip
        pendingPin = pin
        controlPanel.visibility = View.GONE
        viewerContainer.visibility = View.VISIBLE
        setImmersive(true)
        wifiLock = NetUtil.createLowLatencyWifiLock(this).also { it.acquire() }
        // Jika surface sudah ada, langsung jalan; kalau belum, surfaceCreated() yang memicu
        if (surfaceView.holder.surface.isValid) launchViewer()
    }

    private fun stopViewing() {
        pendingIp = null
        stopViewerThread()
        try { wifiLock?.release() } catch (_: Exception) {}
        wifiLock = null
        setImmersive(false)
        viewerContainer.visibility = View.GONE
        controlPanel.visibility = View.VISIBLE
    }

    private fun launchViewer() {
        val ip = pendingIp ?: return
        stopViewerThread()
        val gen = ++viewGeneration
        val pin = pendingPin
        val surface = surfaceView.holder.surface
        viewerThread = Thread({ connectAndDecode(ip, pin, surface, gen) }, "viewer").also { it.start() }
    }

    /** Batalkan sesi: tutup socket (membuka blokir read) lalu tunggu thread selesai sebelum surface hilang. */
    private fun stopViewerThread() {
        viewGeneration++
        try { viewSocket?.close() } catch (_: Exception) {}
        val t = viewerThread
        viewerThread = null
        if (t != null && t !== Thread.currentThread()) {
            try { t.join(800) } catch (_: InterruptedException) {}
        }
    }

    private fun connectAndDecode(ip: String, pin: String, surface: Surface, gen: Int) {
        var socket: Socket? = null
        var decoder: MediaCodec? = null
        var error: String? = null
        try {
            socket = Socket().also { it.tcpNoDelay = true }
            viewSocket = socket
            socket.connect(InetSocketAddress(ip, Protocol.PORT), 5000) // batas waktu: tidak menggantung 2 menit
            if (gen != viewGeneration) return

            socket.soTimeout = 5000
            val out = DataOutputStream(socket.getOutputStream())
            out.writeUTF(pin)
            out.flush()
            val input = DataInputStream(BufferedInputStream(socket.getInputStream(), 64 * 1024))
            if (input.readUnsignedByte() != 1) throw IOException("PIN salah / ditolak")
            socket.soTimeout = 10_000 // pengirim mengirim PING tiap 1 detik saat layar diam

            while (gen == viewGeneration) {
                val type = input.readUnsignedByte()
                val len = input.readInt()
                val pts = input.readLong()
                if (len < 0 || len > 8_000_000) throw IOException("Paket tidak valid")
                val data = ByteArray(len)
                if (len > 0) input.readFully(data)

                when (type) {
                    Protocol.T_HELLO -> {
                        val bb = ByteBuffer.wrap(data)
                        videoW = bb.int
                        videoH = bb.int
                        runOnUiThread { if (gen == viewGeneration) fitSurface() }
                    }
                    Protocol.T_CONFIG -> {
                        decoder?.let { releaseDecoder(it) }
                        val d = createDecoder(videoW, videoH, surface)
                        decoder = d
                        queueInput(d, data, 0, MediaCodec.BUFFER_FLAG_CODEC_CONFIG)
                    }
                    Protocol.T_KEY, Protocol.T_DELTA -> decoder?.let {
                        val flags = if (type == Protocol.T_KEY) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                        queueInput(it, data, pts, flags)
                        drain(it)
                    }
                    else -> { /* PING: abaikan */ }
                }
            }
        } catch (e: Exception) {
            if (gen == viewGeneration) error = e.message ?: e.javaClass.simpleName
        } finally {
            decoder?.let { releaseDecoder(it) }
            try { socket?.close() } catch (_: Exception) {}
        }
        val msg = error
        if (msg != null) {
            runOnUiThread {
                if (gen == viewGeneration) {
                    Toast.makeText(this, "Koneksi terputus: $msg", Toast.LENGTH_LONG).show()
                    stopViewing()
                }
            }
        }
    }

    private fun createDecoder(w: Int, h: Int, surface: Surface): MediaCodec {
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 2 * 1024 * 1024)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
            }
        }
        val c = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        c.configure(fmt, surface, null, 0)
        c.start()
        return c
    }

    private fun releaseDecoder(c: MediaCodec) {
        try { c.stop() } catch (_: Exception) {}
        try { c.release() } catch (_: Exception) {}
    }

    private fun queueInput(codec: MediaCodec, data: ByteArray, pts: Long, flags: Int) {
        var tries = 0
        while (tries < 10) {
            val i = codec.dequeueInputBuffer(10_000)
            if (i >= 0) {
                val b = codec.getInputBuffer(i) ?: return
                b.clear()
                b.put(data)
                codec.queueInputBuffer(i, 0, data.size, pts, flags)
                return
            }
            drain(codec) // decoder penuh: kosongkan output dulu
            tries++
        }
    }

    /** Tampilkan hanya frame terbaru; frame lama yang menumpuk dibuang agar latensi tidak menumpuk. */
    private fun drain(codec: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        var last = -1
        while (true) {
            val o = codec.dequeueOutputBuffer(info, 0)
            if (o >= 0) {
                if (last >= 0) codec.releaseOutputBuffer(last, false)
                last = o
            } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED ||
                o == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED
            ) {
                continue
            } else {
                break
            }
        }
        if (last >= 0) codec.releaseOutputBuffer(last, true)
    }

    /** Pertahankan rasio asli layar pengirim (sebelumnya ditarik penuh -> gepeng). */
    private fun fitSurface() {
        if (videoW <= 0 || videoH <= 0) return
        val cw = viewerContainer.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val ch = viewerContainer.height.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels
        val s = min(cw.toFloat() / videoW, ch.toFloat() / videoH)
        surfaceView.layoutParams = FrameLayout.LayoutParams(
            (videoW * s).toInt(), (videoH * s).toInt(), Gravity.CENTER
        )
    }

    private fun setImmersive(on: Boolean) {
        WindowCompat.setDecorFitsSystemWindows(window, !on)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (on) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }
}
