package com.example.mirrorwifiturbo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

/**
 * Tangkap layar -> encode H.264 (hardware) -> kirim lewat TCP ke penerima yang memasukkan PIN benar.
 *
 * Encoder & VirtualDisplay dibuat SEKALI saat service mulai dan dipakai bersama semua klien
 * (Android 14+ melarang membuat VirtualDisplay kedua dari MediaProjection yang sama).
 */
class ScreenMirrorService : Service() {

    companion object {
        const val ACTION_STOP = "STOP"
        const val EXTRA_RESULT_CODE = "RESULT_CODE"
        const val EXTRA_DATA = "DATA"
        const val EXTRA_PIN = "PIN"
        const val EXTRA_LONG_SIDE = "LONG_SIDE"
        const val EXTRA_BITRATE = "BITRATE"

        private const val TAG = "MirrorService"
        private const val CHANNEL_ID = "mirror_channel"
        private const val MAX_CLIENTS = 3

        @Volatile var running = false
        @Volatile var clientCount = 0
        @Volatile var currentPin = ""
    }

    private class Frame(val type: Int, val pts: Long, val data: ByteArray)

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var encoder: MediaCodec? = null
    private var serverSocket: ServerSocket? = null
    private var encodeThread: Thread? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private val clients = CopyOnWriteArrayList<Client>()

    @Volatile private var config: ByteArray? = null
    private var videoW = 0
    private var videoH = 0
    private var pin = ""
    private var released = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Wajib segera dipanggil setelah startForegroundService(), dengan tipe mediaProjection
        showForegroundNotification()

        if (intent == null || running) return START_NOT_STICKY

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        if (resultCode == 0 || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        pin = intent.getStringExtra(EXTRA_PIN) ?: "000000"
        try {
            startCapture(
                resultCode, data,
                intent.getIntExtra(EXTRA_LONG_SIDE, 1280),
                intent.getIntExtra(EXTRA_BITRATE, 3_000_000)
            )
        } catch (e: Exception) {
            Log.e(TAG, "Gagal memulai capture", e)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun showForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Screen Mirroring", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, ScreenMirrorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("MirrorWiFi Turbo aktif")
            .setContentText("Layar sedang dibagikan lewat WiFi")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentIntent(open)
            .addAction(0, "Berhenti", stop)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 101, n,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        )
    }

    @Suppress("DEPRECATION")
    private fun realDisplaySize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.maximumWindowMetrics.bounds
            return b.width() to b.height()
        }
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    private fun startCapture(resultCode: Int, data: Intent, longSide: Int, bitrate: Int) {
        // Pertahankan rasio layar asli (kelipatan 8) -> tidak gepeng
        val (sw, sh) = realDisplaySize()
        val scale = min(1f, longSide.toFloat() / max(sw, sh))
        videoW = max(16, (sw * scale).toInt() / 8 * 8)
        videoH = max(16, (sh * scale).toInt() / 8 * 8)
        val dpi = resources.displayMetrics.densityDpi

        // Server dulu: kalau port bentrok, gagal lebih awal sebelum menangkap layar
        val server = ServerSocket().apply {
            reuseAddress = true
            bind(InetSocketAddress(Protocol.PORT))
        }
        serverSocket = server

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, videoW, videoH).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, 30)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
            setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR)
            setInteger(MediaFormat.KEY_PRIORITY, 0)
            // Layar diam tetap mengirim ulang frame tiap 300 ms
            setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 300_000L)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val inputSurface = enc.createInputSurface()
        enc.start()
        encoder = enc

        // Android 14+: callback WAJIB didaftarkan sebelum createVirtualDisplay
        val proj = (getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager)
            .getMediaProjection(resultCode, data)
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf() // pengguna menghentikan dari chip/notifikasi sistem
            }
        }, Handler(Looper.getMainLooper()))
        projection = proj

        virtualDisplay = proj.createVirtualDisplay(
            "MirrorDisplay", videoW, videoH, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            inputSurface, null, null
        )

        wifiLock = NetUtil.createLowLatencyWifiLock(this).also { it.acquire() }

        currentPin = pin
        running = true
        encodeThread = Thread({ encodeLoop(enc) }, "mirror-encode").also { it.start() }
        Thread({ acceptLoop(server) }, "mirror-accept").start()
        Log.i(TAG, "Mulai ${videoW}x$videoH @ $bitrate bps, port ${Protocol.PORT}")
    }

    private fun acceptLoop(server: ServerSocket) {
        while (running) {
            val s = try {
                server.accept()
            } catch (e: IOException) {
                break
            }
            if (clients.size >= MAX_CLIENTS) {
                try { s.close() } catch (_: IOException) {}
                continue
            }
            s.tcpNoDelay = true
            Thread(Client(s), "mirror-client").start()
        }
    }

    private fun encodeLoop(enc: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        while (running) {
            val idx = try {
                enc.dequeueOutputBuffer(info, 100_000)
            } catch (e: IllegalStateException) {
                break
            }
            if (idx < 0) continue
            val buf = enc.getOutputBuffer(idx)
            if (buf != null && info.size > 0) {
                buf.position(info.offset)
                buf.limit(info.offset + info.size)
                val bytes = ByteArray(info.size)
                buf.get(bytes)
                when {
                    info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0 -> config = bytes
                    else -> {
                        val type = if (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0)
                            Protocol.T_KEY else Protocol.T_DELTA
                        val f = Frame(type, info.presentationTimeUs, bytes)
                        for (c in clients) c.offer(f)
                    }
                }
            }
            try {
                enc.releaseOutputBuffer(idx, false)
            } catch (e: IllegalStateException) {
                break
            }
        }
    }

    private fun requestKeyFrame() {
        try {
            encoder?.setParameters(Bundle().apply {
                putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
            })
        } catch (e: Exception) {
            Log.w(TAG, "requestKeyFrame gagal: ${e.message}")
        }
    }

    /** Satu klien = satu thread + antrean sendiri, jadi klien lambat tidak menahan encoder/klien lain. */
    private inner class Client(private val socket: Socket) : Runnable {
        private val queue = LinkedBlockingQueue<Frame>(90)
        @Volatile private var alive = true
        @Volatile private var needKey = true

        fun offer(f: Frame) {
            if (!alive) return
            if (needKey) {
                if (f.type != Protocol.T_KEY) return
                needKey = false
            }
            if (!queue.offer(f)) {
                // Jaringan tidak sanggup mengejar: buang antrean, lanjut dari keyframe berikutnya
                queue.clear()
                needKey = true
                requestKeyFrame()
            }
        }

        fun close() {
            alive = false
            try { socket.close() } catch (_: IOException) {}
        }

        override fun run() {
            try {
                // 1) Autentikasi PIN (batas waktu 4 detik)
                socket.soTimeout = 4000
                val input = DataInputStream(socket.getInputStream())
                val out = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), 128 * 1024))
                val given = try { input.readUTF() } catch (e: Exception) { "" }
                val ok = MessageDigest.isEqual(given.toByteArray(), pin.toByteArray())
                out.writeByte(if (ok) 1 else 0)
                out.flush()
                if (!ok) {
                    Thread.sleep(500) // perlambat tebak-tebakan PIN
                    return
                }
                socket.soTimeout = 0

                clients.add(this)
                clientCount = clients.size

                // 2) HELLO + CONFIG (SPS/PPS)
                writeFrame(
                    out, Protocol.T_HELLO, 0,
                    ByteBuffer.allocate(8).putInt(videoW).putInt(videoH).array()
                )
                var cfg = config
                var waited = 0
                while (cfg == null && waited < 40 && alive) {
                    Thread.sleep(50); cfg = config; waited++
                }
                if (cfg == null) return
                writeFrame(out, Protocol.T_CONFIG, 0, cfg)
                out.flush()
                requestKeyFrame()

                // 3) Alirkan frame; kirim PING bila layar diam > 1 detik
                while (alive && running) {
                    val f = queue.poll(1, TimeUnit.SECONDS)
                    if (f == null) {
                        writeFrame(out, Protocol.T_PING, 0, ByteArray(0))
                    } else {
                        writeFrame(out, f.type, f.pts, f.data)
                    }
                    out.flush()
                }
            } catch (e: Exception) {
                Log.d(TAG, "Klien terputus: ${e.message}")
            } finally {
                close()
                clients.remove(this)
                clientCount = clients.size
            }
        }
    }

    private fun writeFrame(out: DataOutputStream, type: Int, pts: Long, data: ByteArray) {
        out.writeByte(type)
        out.writeInt(data.size)
        out.writeLong(pts)
        out.write(data)
    }

    @Synchronized
    private fun shutdown() {
        if (released) return
        released = true
        running = false
        currentPin = ""
        try { serverSocket?.close() } catch (_: Exception) {}
        clients.forEach { it.close() }
        clients.clear()
        clientCount = 0
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { encodeThread?.join(400) } catch (_: Exception) {}
        try { encoder?.stop() } catch (_: Exception) {}
        try { encoder?.release() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { wifiLock?.release() } catch (_: Exception) {}
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}
