package com.example.mirrorwifiturbo

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import java.net.Inet4Address
import java.net.NetworkInterface

// Format paket TCP (big-endian):
//   type (1 byte), panjang data (4 byte), pts (8 byte), lalu data
//
// Jabat tangan: penerima mengirim PIN (writeUTF), pengirim membalas 1 byte (1 = OK, 0 = ditolak).
//
// HELLO  : data = lebar (int) + tinggi (int)
// CONFIG : SPS/PPS H.264 (Annex-B)
// KEY    : keyframe (IDR)
// DELTA  : frame biasa
// PING   : kosong, penanda koneksi masih hidup saat layar diam
object Protocol {
    const val PORT = 8888
    const val T_HELLO = 0
    const val T_CONFIG = 1
    const val T_KEY = 2
    const val T_DELTA = 3
    const val T_PING = 4
}

object NetUtil {
    /** Semua IPv4 privat (WiFi, hotspot, USB tethering). Lebih andal daripada WifiManager.connectionInfo. */
    fun localIps(): List<String> = try {
        NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { ni ->
                ni.inetAddresses.toList()
                    .filter { it is Inet4Address && it.isSiteLocalAddress }
                    .mapNotNull { it.hostAddress }
            }
    } catch (e: Exception) {
        emptyList()
    }

    /** Matikan power-saving WiFi supaya latensi stabil. */
    @Suppress("DEPRECATION")
    fun createLowLatencyWifiLock(ctx: Context): WifiManager.WifiLock {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
        else WifiManager.WIFI_MODE_FULL_HIGH_PERF
        return wm.createWifiLock(mode, "MirrorWiFiTurbo").apply { setReferenceCounted(false) }
    }
}
